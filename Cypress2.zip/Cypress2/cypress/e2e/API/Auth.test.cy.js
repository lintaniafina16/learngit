/// <reference types="cypress" />

describe('Inputing with input', () =>{
    
    it('Successfully login using headers',() => {
        cy.loginViaAPI()
        cy.get('p').should('include.text', 'Congratulations! You must have the proper credentials.')
    })

})